<?php
/**
 * qGuestbook, Simple PHP Guestbook
 *
 * Mit qFTP ist es möglich, sehr schnell und simpel eine
 * Verbindung zu einem FTP-Server aufzubauen und dort
 * Dateien hoch-/herunterzuladen oder zu bearbeiten.
 *
 * PHP Version 5
 *
 * LICENSE: This program is free software; you can redistribute it
 * and/or modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2 of
 * the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 *
 * @package     qGuestbook
 * @subpackage  qFTP
 * @author      Simon Lauger <admin@simlau.net>
 * @copyright   2006-2007 Simon Lauger
 * @license     http://opensource.org/licenses/gpl-license.php GNU Public License
 * @version     0.2.1
 * @link        http://www.simlau.net/
 * @since       File available since Release 0.2.1
 */

if (!defined('GUESTBOOK'))
{
	die('Hacking attempt!');
	exit;
}

Class qFTP {
	
	/**
	  * Hostname zu dem verbunden wird
	  * 
	  * @var string
	  * @access protected
	  */
	protected $hostname;
	
	/**
	  * FTP-Benutzername
	  *
	  * @var string
	  * @access protected
	  */
	protected $username;
	
	/**
	  * FTP-Benutzerpasswort
	  * 
	  * @var string
	  * @access protected
	  */
	protected $password;
	
	/**
	  * FTP-Ping Timeout
	  * 
	  * @var int
	  * @access protected
	  */
	protected $timeout;
	
	/**
	  * FTP SSL Verbindung
	  * 
	  * @var bool
	  * @access protected
	  */
	protected $ssl;
	
	/**
	  * FTP-Port
	  * 
	  * @var int
	  * @access protected
	  */
	protected $port;
	
	/**
	  * Construct-Funktion
	  *
	  * @param string $hostname     Der Hostname zu dem verbunden wird
	  * @param string $username     Der Benutzername
	  * @param string $password     Das Benutzerpasswort
	  * @param string $port         FTP Port
	  * @param string $ssl          Wird eine SSL Verbindung aufgebaut?
	  * @param string $timeout      Ping Timeout (Nur für SSL)
	  * @return bool                Wenn erfolgreich dann TRUE, sonst FALSE
	  *
	  * @access public
	  */
	public function __construct($hostname, $username, $password, $port = 21, $ssl = false, $timeout = 90) {
		/*
		 * Klassenvariablen
		 */
		$this->hostname = $hostname;
		$this->username = $username;
		$this->password = $password;
		$this->timeout  = $timeout;
		$this->ssl      = $ssl;
		$this->port     = $port;
		
		/*
		 * Verbindung aufbauen
		 */
		if ( !$this->qConnect() ) {
			return false;
		}
		
		/*
		 * Einloggen
		 */
		if ( !$this->qLogin() ) {
			return false;
		}
		
		/*
		 * Fertig
		 */
		if ( $this->conn_id ) {
			return true;
		} else {
			return false;
		}
	}
	
	// Verbinden
	public function qConnect() {
		/*
		 * Wird eine SSL Verbindung aufgebaut?
		 */
		if ( $this->ssl == true ) {
			$this->conn_id = ftp_ssl_connect($this->hostname, $this->port, $this->timeout);
		} else {
			$this->conn_id = ftp_connect($this->hostname, $this->port);
		}
		/*
		 * War das Verbinden erfolgreich?
		 */
		if ( $this->conn_id == false ) {
			return false;
		} else {
			return true;
		}
	}
	
	// Einloggen
	public function qLogin() {
		/*
		 * Auf dem FTP-Server einloggen
		 */
		if ( ftp_login($this->conn_id, $this->username, $this->password) ) {
			return true;
		} else {
			return false;
		}
	}
	
	// Verbindung beenden
	public function qClose() {
		/*
		 * Verbindung beenden
		 */
		ftp_close($this->conn_id);
	}
	
	// Upload
	public function qUpload($remote_file, $local_file, $ftp_mode = 'ASCII') {
		/*
		 * Modus bestimmen
		 */
		switch ( $ftp_mode ) {
			case 'BINARY':
				$ftp_method = FTP_BINARY;
				break;
			case 'ASCII':
				$ftp_method = FTP_ASCII;
				break;
			default:
				$ftp_method = FTP_ASCII;
		}
		/*
		 * Datei herunterladen
		 */
		if ( ftp_put($this->conn_id, $remote_file, $local_file, $ftp_method) ) {
			return true;
		} else {
			return false;
		}
	}
	
	// Download
	public function qDownload($local_file, $remote_file, $ftp_mode = 'ASCII') {
		/*
		 * Modus bestimmen
		 */
		switch ( $ftp_mode ) {
			case 'BINARY':
				$ftp_method = FTP_BINARY;
				break;
			case 'ASCII':
				$ftp_method = FTP_ASCII;
				break;
			default:
				$ftp_method = FTP_ASCII;
		}
		/*
		 * Datei hochladen
		 */
		if ( ftp_get($this->conn_id, $remote_file, $local_file, $ftp_method) ) {
			return true;
		} else {
			return false;
		}
	}
	
	/**
	  * Löscht eine Datei auf dem Remote FTP-Server.
	  *
	  * @param string $remote_file  Datei, die gelöscht werden soll.
	  * @return bool                Wenn erfolgreich dann TRUE, sonst FALSE.
	  *
	  * @access public
	  */
	public function qDelete($remote_file) {
		if ( ftp_delete($this->conn_id, $remote_file) ) {
			return true;
		} else {
			return false;
		}
	}
	
	/**
	  * Verschiebt eine Datei auf dem Remote FTP-Server.
	  * 
	  * @param string $remote_file  Datei, die verschoben werden soll.
	  * @param string $new_name     Neuer Pfad oder Dateiname.
	  * @return bool                Wenn erfolgreich dann TRUE, sonst FALSE.
	  *
	  * @access public
	  */
	public function qRename($remote_file, $new_name) {
		if ( ftp_rename($this->conn_id, $remote_file, $new_name) ) {
			return true;
		} else {
			return false;
		}
	}
	
	/**
	  * Wechselt das aktuelle Verzeichniss auf dem Remote FTP-Server.
	  *
	  * @param string $directory    Verzeichniss, in das gewechselt werden soll.
	  * @return bool                Wenn erfolgreich dann TRUE, sonst FALSE.
	  *
	  * @access public
	  */
	public function qChdir($directory) {
		if ( ftp_chdir($this->conn_id, $directory) ) {
			return true;
		} else {
			return false;
		}
	}
	
	/**
	  * Ämdert die Zugriffsrechte einer Datei auf dem Remote FTP-Server.
	  *
	  * @param string $mode         Neuer Modus der Datei (z. B. 0666).
	  * @param string $remote_file  Datei auf dem Server.
	  * @return bool                Wenn erfolgreich dann TRUE, sonst FALSE.
	  *
	  * @access public
	  */
	public function qChmod($mode, $remote_file) {
		if ( ftp_chmod($this->conn_id, $mode, $remote_file) ) {
			return true;
		} else {
			return false;
		}
	}
	
	/**
	  * Erstellt ein Verzeichniss auf dem Remote FTP-Server.
	  *
	  * @param string $directory    Pfad des neuen Verzeichnisses
	  * @return string              Wenn erfolgreich dann der Name des
	  *                             Verzeichnisses, ansonsten FALSE.
	  * @access public
	  */
	public function qMkdir($directory) {
		if ( $name = ftp_mkdir($this->conn_id, $directory) ) {
			return $name;
		} else {
			return false;
		}
	}

	/**
	  * Löscht ein Verzeichniss auf dem Remote FTP-Server.
	  *
	  * @param string $directory    Pfad des zu löschenden Verzeichnisses
	  * @return string              Wenn erfolgreich dann der Name des
	  *                             Verzeichnisses, ansonsten FALSE.
	  *
	  * @access public
	  */
	public function qRmdir($directory) {
		if ( ftp_rmdir($this->conn_id, $directory) ) {
			return true;
		} else {
			return false;
		}
	}
	
	/**
	  * Liefert das aktuelle Verzeichniss.
	  *
	  * @return string              Name des aktuellen Verzeichnisses.
	  *
	  * @access public
	  */
	public function qPwd() {
		$pwd = ftp_pwd($this->conn_id);
		return $pwd;
	}
	
	/**
	  * Gibt den Servertyp des FTP Streams zurück.
	  *
	  * @return string              Liefert den Servertyp (z. B. UNIX).
	  *
	  * @access public
	  */
	public function qSystype() {
		if ( $type = ftp_systype($this->conn_id) ) {
			return $type;
		} else {
			return false;
		}
	}

	/**
	  * Führt ein Kommando auf dem Remote FTP-Server aus.
	  *
	  * @param string $command      Auszuführendes Kommando.
	  * @return string              Wenn erfolgreich dann TRUE, ansonsten FALSE.
	  *
	  * @access public
	  */
	public function qExec($command) {
		if ( $result = ftp_exec($this->conn_id, $command) ) {
			return true;
		} else {
			return false;
		}
	}
	
	// alias
	public function qRaw($directory) {
		$result = ftp_rawlist($this->conn_id, $directory);
		return $result;
	}
	
	// alias
	public function qRawlist($command) {
		$result = ftp_raw($this->conn_id, $command);
		return $result;
	}
	
	/**
	  * Setzt eine Option für den FTP Stream oder setzt die Option auf den Standart-Wert
	  * zurück.
	  *
	  * @param string $option       Option die gesetzt werden soll.
	  * @param string $option       Wert der gesetzt werden soll. Wenn kein Wert
	  *                             angegeben ist, wird die Option auf den Standart-Wert
	  *                             zurückgesetzt.
	  * @return string              Wenn erfolgreich dann der Name des
	  *                             Verzeichnisses, ansonsten FALSE
	  *
	  * @access public
	  */
	public function qSetOption($option, $value = 'default') {
		switch ( $option ) {
			case FTP_TIMEOUT_SEC:
				if ( $value == 'default' ) {
					$value = 90;
				}
				if ( $result = ftp_set_option($this->conn_id, FTP_TIMEOUT_SEC, $value) ) {
					return true;
				} else {
					return false;
				}
				break;
			case FTP_AUTOSEEK:
				if ( $value == 'default' ) {
					$value = true;
				}
				if ( $result = ftp_set_option($this->conn_id, FTP_AUTOSEEK, $value) ) {
					return true;
				} else {
					return false;
				}
				break;
			default:
				return false;
		}
	}
	
	// alias
	public function qGetOption($option) {
		if ( $result = ftp_get_option($this->conn_id, $value) ) {
			return $result;
		} else {
			return false;
		}
	}
	
	/**
	  * Ermittelt die Größe einer angegebenen Datei.
	  *
	  * @param string $remote_file Datei deren Dateigröße ermittelt werden soll.
	  * @return string             Gibt die Dateigröße oder FALSE bei Fehlern zurück.
	  *
	  * @access public
	  */
	public function qSize($remote_file) {
		if ( ($result = ftp_size($this->conn_id, $remote_file)) == -1 ) {
			return false;
		} else {
			return $result;
		}
	}
	
	/**
	  * Gibt ein Array mit dem im Verzeichniss vorhandenen Dateien aus
	  *
	  * @param string $directory  Verzeichniss das ausgelesen werden soll
	  * @return array             Array mit den Dateinamen, bei Fehlern FALSE
	  *
	  * @access public
	  */
	public function qNlist($directory) {
		if ( $result = ftp_nlist($this->conn_id, $directory) ) {
			return $result;
		} else {
			return false;
		}
	}
	
	/**
	  * Ermittelt die letzte Änderungszeit der angegebenen Datei
	  *
	  * @param string $remote_file  Verzeichniss das ausgelesen werden soll
	  * @return string              Letzte änderung der Datei, bei Fehlern FALSE
	  *
	  * @access public
	  */
	public function qMdtm($remote_file) {
		if ( ($result = ftp_mdtm($this->conn_id, $directory)) == -1 ) {
			return false;
		} else {
			return $result;
		}
	}
	
	/**
	  * Läd einge geöffnete Datei auf den Server
	  *
	  * @param string $remote_file  Verzeichniss das ausgelesen werden soll
	  * @return bool                Wenn erfolgreich dann TRUE, bei Fehlern FALSE
	  *
	  * @access public
	  */
	public function qFput($remote_file, $ftp_mode = 'ASCII') {
		/*
		 * Modus bestimmen
		 */
		switch ( $ftp_mode ) {
			case 'BINARY':
				$ftp_method = FTP_BINARY;
				break;
			case 'ASCII':
				$ftp_method = FTP_ASCII;
				break;
			default:
				$ftp_method = FTP_ASCII;
		}
		if ( $result = ftp_fput($this->conn_id, $remote_file, $ftp_method) ) {
			return true;
		} else {
			return false;
		}
	}
	
	/**
	  * Lädt eine Datei vom FTP-Server und speichert sie in eine geöffnete, lokale Datei
	  *
	  * @param string $fp         Datei in die geschrieben werden soll
	  * @return bool              Wenn erfolgreich dann TRUE, bei Fehlern FALSE
	  *
	  * @access public
	  */
	public function qFget($fp, $remote_file, $ftp_mode = 'ASCII') {
		/*
		 * Modus bestimmen
		 */
		switch ( $ftp_mode ) {
			case 'BINARY':
				$ftp_method = FTP_BINARY;
				break;
			case 'ASCII':
				$ftp_method = FTP_ASCII;
				break;
			default:
				$ftp_method = FTP_ASCII;
		}
		if ( $result = ftp_fput($this->conn_id, $fp, $remote_file, $ftp_method) ) {
			return true;
		} else {
			return false;
		}
	}
	
}

/*
 * Example:
 *
 * define('qFTP', true);
 * require_once 'Class.qFTP.php';
 *
 * if ( !class_exists('qFTP') ) {
 * 	die('Class qFTP required!');
 * }
 *
 * $ftp = new qFTP('example.net', 'root', 'example');
 * $file_list = $ftp->qNlist('./');
 * $sys_type  = $ftp->qSystype();
 * $ftp->qDownload('./downloads/example.txt', './files/example.txt');
 * $ftp->qMkdir('./files/old');
 * $ftp->qRename('./files/example.txt', './files/old/example.txt');
 * $ftp->qClose();
 */

?>