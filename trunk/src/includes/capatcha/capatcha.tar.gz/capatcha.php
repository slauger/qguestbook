<?php
/**
 * qLanguage
 *
 * Die Visual Confirmation von qGuestbook.
 *
 * <code>
 * <?php
 *
 * require_once 'capatcha.php';
 * $capatcha = new qCapatcha;
 *
 * ?>
 * </code>
 *
 * @author      Simon Lauger <admin@simlau.net>
 * @package     qGuestbook
 * @version     1.0.0
 * @subpackage  qCapatcha
 * @license http://opensource.org/licenses/gpl-license.php GNU Public License
 */

// formular sollte 130px x 24px haben
error_reporting(E_ALL);

Class Capatcha
{
	private $capatcha_length;
	private $font_size;
	private $img_width;
	private $img_height;
	private $fonts = array();

	public function __construct()
	{
		$this->capatcha_length = 5;
		$this->font_size = 10;
		$this->img_width = 130; //170;
		$this->img_height = 24; // 60;
	}

	public function set_fonts($array)
	{
		foreach ($array as $value)
		{
			$this->fonts[] = $value;
		}
	}

	public function set_alphabet($array)
	{
		foreach ($array as $value)
		{
			$this->alphabet[] = $value;
		}
	}

	public function create_image()
	{
		header('Content-Type: image/jpeg', true);
		$img = imagecreatetruecolor($this->img_width, $this->img_height);
		$col = imagecolorallocate($img, rand(200, 255), rand(200, 255), rand(200, 255));
		imagefill($img, 0, 0, $col);

		$captcha = '';
		$x = 10;

		if (empty($this->fonts))
		{
			die('<b>Capatcha Error:</b> no font selected');
		}

		if (empty($this->alphabet))
		{
			die('<b>Capatcha Error:</b> alphabet noch selected');
		}

		for ($i = 0; $i < $this->capatcha_length; $i++)
		{
			$chr = $this->alphabet[rand(0, count($this->alphabet) - 1)];
			$captcha .= $chr;
			$col = imagecolorallocate($img, rand(0, 199), rand(0, 199), rand(0, 199));
			$font = $this->fonts[rand(0, count($this->fonts) - 1)];
			$y = 18; #+ rand(0, 20);
			$angle = rand(0, 30);
			imagettftext($img, $this->font_size, $angle, $x, $y, $col, $font, $chr);
			$dim = imagettfbbox($this->font_size, $angle, $font, $chr);
			$x += $dim[4] + abs($dim[6]) + 10;
		}

		imagejpeg($img);
		imagedestroy($img);
	}
}

?>