<?php
/**
 * qGuestbook, a PHP Guestbook
 *
 * @author      Simon Lauger <admin@simlau.net>
 * @package     qGuestbook
 * @version     0.2.0
 * @subpackage  qCapatcha
 * @license http://opensource.org/licenses/gpl-license.php GNU Public License
 */

error_reporting(E_ALL);
require_once dirname(__FILE__) . '/capatcha.php';

$capatcha = new Capatcha;
$capatcha->set_fonts(array('fonts/akbar.ttf'));
$capatcha->set_alphabet(array('A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'Q', 'J', 'K', 'L', 'M', 'N', 'P', 'R', 'S', 'T', 'U', 'V', 'Y', 'W', '2', '3', '4', '5', '6', '7'));
$capatcha->create_image();

?>